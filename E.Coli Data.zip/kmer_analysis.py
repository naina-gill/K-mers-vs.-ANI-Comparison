# ---------- Imports ----------
import os
import pandas as pd
from skbio import DNA
from collections import Counter
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from scipy.spatial.distance import pdist, squareform
from skbio.stats.distance import permanova, DistanceMatrix
import matplotlib.pyplot as plt

# ---------- Configuration ----------
genome_folder = "/mnt/c/Users/anyag/bioinfo_project_folder/genomes"
metadata_file = os.path.join(genome_folder, "strain_metadata.csv")
k_values = range(3, 8)
n_clusters = 3

# ---------- Label Mapping ----------
label_map = {
    "EColi_K12_MG_1655_BVBRC_genome_sequence.fasta": "E. coli K-12 MG1655",
    "EColi_O157_H7_Sakai_BVBRC_genome_sequence.fasta": "E. coli O157:H7 Sakai",
    "EAlbertii_167_BVBRC_genome_sequence.fasta": "E. albertii Sample 167",
    "E_Albertii_BIA_5-2_BVBRC_genome_sequence.fasta": "E. albertii BIA_5-2",
    "EFergusonii_FDAARGOS_1499_BVBRC_genome_sequence.fasta": "E. fergusonii FDAARGOS_1499",
    "EMarmotae_YF8_BVBRC_genome_sequence.fasta": "E. marmotae YF8",
    "EMarmotae_H1_003_0086_C_F_BVBRC_genome_sequence.fasta": "E. marmotae H1-003-0086-C-F",
    "ERuysiae_AB136_BVBRC_genome_sequence.fasta": "E. ruysiae AB136",
    "ERuysiae_C61-1_BVBRC_genome_sequence.fasta": "E. ruysiae C61-1",
    "EAlba_B35_BVBRC_genome_sequence.fasta": "E. alba B35",
    "EWhittamii_C2-3_BVBRC_genome_sequence.fasta": "E. whittamii C2-3",
    "E_Sa_2BVA5_BVBRC_genome_sequence.fasta": "E. sp. Sa2BVA5"
}

# ---------- Metadata Setup ----------
if not os.path.exists(metadata_file):
    strain_metadata = {
        "E. coli K-12 MG1655": "lab",
        "E. coli O157:H7 Sakai": "human_pathogen",
        "E. albertii Sample 167": "poultry",
        "E. albertii BIA_5-2": "poultry",
        "E. fergusonii FDAARGOS_1499": "environment",
        "E. marmotae YF8": "wildlife",
        "E. marmotae H1-003-0086-C-F": "wildlife",
        "E. ruysiae AB136": "environment",
        "E. ruysiae C61-1": "environment",
        "E. alba B35": "wildlife",
        "E. whittamii C2-3": "wildlife",
        "E. sp. Sa2BVA5": "unknown"
    }
    pd.DataFrame(list(strain_metadata.items()), columns=["Strain", "Niche"]).to_csv(metadata_file, index=False)

metadata_df = pd.read_csv(metadata_file)
metadata_df.set_index("Strain", inplace=True)

# ---------- Benchmark Loop ----------
results = []

for k in k_values:
    print(f"\nRunning pipeline for k = {k}")
    
    # K-mer profiling
    profiles = {}
    for file_name in os.listdir(genome_folder):
        if file_name.endswith(".fasta") and file_name in label_map:
            strain = label_map[file_name]
            with open(os.path.join(genome_folder, file_name)) as f:
                sequence = "".join([line.strip() for line in f if not line.startswith(">")])
            try:
                dna = DNA(sequence.upper())
            except:
                continue
            counts = Counter(str(dna[i:i+k]) for i in range(len(dna) - k + 1))
            total = sum(counts.values())
            for kmer in counts:
                counts[kmer] /= total
            profiles[strain] = counts

    df = pd.DataFrame.from_dict(profiles, orient="index").fillna(0)
    
    # PCA + clustering
    pca = PCA(n_components=2)
    coords = pca.fit_transform(df.values)
    pca_df = pd.DataFrame(coords, columns=["PC1", "PC2"], index=df.index)
    pca_df["Cluster"] = KMeans(n_clusters=n_clusters, random_state=42).fit_predict(pca_df[["PC1", "PC2"]])
    pca_df["Niche"] = pca_df.index.map(metadata_df["Niche"])
    
    # Silhouette score
    silhouette = silhouette_score(pca_df[["PC1", "PC2"]], pca_df["Cluster"])
    
    # PERMANOVA
    valid_df = pca_df.dropna(subset=["Niche"])
    if len(valid_df) >= 2:
        dist = squareform(pdist(valid_df[["PC1", "PC2"]]))
        dm = DistanceMatrix(dist, ids=valid_df.index)
        perma_p = permanova(dm, grouping=valid_df["Niche"])["p-value"]
    else:
        perma_p = None
    
    # Top k-mer loadings (PC1)
    loadings = pd.Series(pca.components_[0], index=df.columns)
    top_kmers = loadings.abs().sort_values(ascending=False).head(10)
    top_kmers_df = pd.DataFrame({
        "kmer": top_kmers.index,
        "loading": top_kmers.values,
        "k": k
    })
    top_kmers_df.to_csv(os.path.join(genome_folder, f"top_kmers_k{k}.csv"), index=False)
    
    results.append({
        "k": k,
        "silhouette": silhouette,
        "permanova_p": perma_p
    })

# ---------- Save and Plot Summary ----------
summary_df = pd.DataFrame(results)
summary_df.to_csv(os.path.join(genome_folder, "kmer_benchmark_summary.csv"), index=False)

plt.figure(figsize=(10, 6))
plt.plot(summary_df["k"], summary_df["silhouette"], marker="o", label="Silhouette Score")
plt.plot(summary_df["k"], summary_df["permanova_p"], marker="s", label="PERMANOVA p-value")
plt.axhline(0.05, linestyle="--", color="gray", label="Significance Threshold")
plt.xlabel("k-mer size (k)")
plt.ylabel("Score / p-value")
plt.title("Benchmark of k-mer sizes")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(genome_folder, "kmer_benchmark_plot.png"))

print("\nBenchmarking complete. Outputs saved to:")
print(genome_folder)