import os
import csv
from collections import Counter
from Bio import SeqIO

# ----- Parameters you can adjust -----
k = 5  # k-mer length (try 4–8 based on resolution you want)
input_folder = "."  # Folder containing .fna files
output_file = f"kmer_matrix_k{k}.tsv"  # Output matrix filename

# ----- Helper function: canonicalize k-mers -----
def canonical_kmer(kmer):
    """
    Returns the lexicographically smaller of a k-mer or its reverse complement.
    This helps treat symmetric sequences like ACGT and its reverse as the same unit.
    """
    revcomp = kmer.translate(str.maketrans("ACGT", "TGCA"))[::-1]
    return min(kmer, revcomp)

# ----- Collect data from all genomes -----
all_kmers = set()  # set of all k-mers seen across files
genome_vectors = {}  # dict mapping genome ID → frequency dict

# Loop over all .fna files in the folder
for filename in os.listdir(input_folder):
    if filename.endswith(".fna"):
        genome_id = filename.split("_")[-1].replace(".fna", "")
        full_path = os.path.join(input_folder, filename)

        # Read all sequences in the file
        kmer_counter = Counter()
        for record in SeqIO.parse(full_path, "fasta"):
            sequence = str(record.seq).upper()
            for i in range(len(sequence) - k + 1):
                kmer = sequence[i:i+k]
                if set(kmer) <= {"A", "C", "G", "T"}:  # skip ambiguous bases
                    canonical = canonical_kmer(kmer)
                    kmer_counter[canonical] += 1

        # Normalize counts to proportions
        total_kmers = sum(kmer_counter.values())
        frequencies = {k: count / total_kmers for k, count in kmer_counter.items()}

        genome_vectors[genome_id] = frequencies
        all_kmers.update(frequencies.keys())

# ----- Write output matrix -----
sorted_kmers = sorted(all_kmers)
with open(output_file, "w", newline="") as out:
    writer = csv.writer(out, delimiter="\t")
    writer.writerow(["Genome ID"] + sorted_kmers)

    for genome_id, freq_dict in genome_vectors.items():
        row = [genome_id] + [freq_dict.get(kmer, 0.0) for kmer in sorted_kmers]
        writer.writerow(row)

print(f"K-mer matrix saved to: {output_file}")