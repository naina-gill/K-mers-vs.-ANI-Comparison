import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

# ----- File paths -----
kmer_file = "kmer_matrix_k5.tsv"
metadata_file = "staph_metadata.tsv"

# ----- Load k-mer matrix -----
kmer_df = pd.read_csv(kmer_file, sep="\t")
print(f"K-mer matrix shape: {kmer_df.shape}")

# ----- Load metadata -----
metadata_df = pd.read_csv(metadata_file, sep="\t")
print(f"Metadata shape: {metadata_df.shape}")

# ----- Merge by Genome ID -----
merged_df = pd.merge(kmer_df, metadata_df, on="Genome ID")
print(f"Merged data shape: {merged_df.shape}")

# ----- Run PCA -----
X = merged_df.iloc[:, 1:len(kmer_df.columns)].values  # k-mer features only
pca = PCA(n_components=2)
components = pca.fit_transform(X)

# ----- Plot PCA -----
plt.figure(figsize=(8, 6))
colors = merged_df["Isolation Source"]  # Change to "Host" or "Country" if preferred
for source in colors.unique():
    idx = colors == source
    plt.scatter(components[idx, 0], components[idx, 1], label=source, s=60)

plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("PCA of k-mer Profiles (k=5)")
plt.legend()
plt.tight_layout()
plt.savefig("pca_kmer_plot.png")
plt.show()