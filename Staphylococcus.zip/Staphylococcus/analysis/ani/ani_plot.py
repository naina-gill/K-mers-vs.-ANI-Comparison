import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load long-form ANI output from FastANI
df = pd.read_csv("fastani_output.txt", sep='\t', header=None)

# Rename columns based on FastANI format (5 fields)
df.columns = ["query", "reference", "ANI", "fragments", "mapped"]

# Clean up file paths: just show genome IDs
def clean_id(path):
    return path.split("/")[-1].replace(".fna", "")

df["query"] = df["query"].apply(clean_id)
df["reference"] = df["reference"].apply(clean_id)

# Pivot into a square ANI matrix
ani_matrix = df.pivot(index="query", columns="reference", values="ANI")

# Plot heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(ani_matrix, cmap="viridis", annot=False, xticklabels=True, yticklabels=True)
plt.title("Pairwise ANI of Staphylococcus Genomes")
plt.xlabel("Reference Genome")
plt.ylabel("Query Genome")
plt.xticks(rotation=90)
plt.yticks(rotation=0)
plt.tight_layout()
plt.savefig("ani_heatmap.png", dpi=300)
plt.show()