import os
import shutil
import re

# Base project folder and species
base_dir = r"C:\Users\anyag\bioinfo_project_folder"
species = "Staphylococcus"
species_dir = os.path.join(base_dir, species)

# Folder layout and matching patterns
structure = {
    "data/raw_genomes": [r"\.fna$"],
    "data/cleaned_ids": [r"verify_genomes", r"download_fasta", r"clean_ids"],
    "data/metadata": [r"metadata", r"bvbrc"],
    "analysis/ani": [r"fastani", r"ani_plot", r"ani_heatmap"],
    "analysis/kmer": [r"kmer_profile", r"pca_kmer_plot"],
    "analysis/pca": [r"pca_plot"],
    "analysis/clustering": [r"genome_paths", r"clean_ids"],
    "results/figures": [r"plot", r"heatmap"],
    "results/tables": [r"\.tsv$", r"\.csv$", r"matrix"],
    "scripts": [r"\.py$", r"\.R$"],
    "docs/screenshots": [r"screenshot", r"\.png$", r"\.jpg$"],
    "archive": [r"temp", r"old", r"backup"]
}

def classify(filename):
    for folder, patterns in structure.items():
        for pat in patterns:
            if re.search(pat, filename, re.IGNORECASE):
                return folder
    return "archive"

def organize_species():
    os.makedirs(species_dir, exist_ok=True)
    files = [f for f in os.listdir(base_dir) if os.path.isfile(os.path.join(base_dir, f))]
    
    for fname in files:
        source = os.path.join(base_dir, fname)
        subfolder = classify(fname)
        dest = os.path.join(species_dir, subfolder)
        os.makedirs(dest, exist_ok=True)
        shutil.copy2(source, os.path.join(dest, fname))

organize_species()
print(f"✅ Files sorted into '{species}/' inside your bioinfo_project_folder.")