import pandas as pd

groups = pd.read_csv("../results/ani/genome_groups.tsv", sep="\t")
meta = pd.read_csv("../metadata/sample_metadata.csv")

# standardize filenames
groups["filename"] = groups["genome"].astype(str) + ".fna"

# identify missing entries
missing = set(groups["filename"]) - set(meta["filename"])
print("Genomes missing from metadata:", missing)
