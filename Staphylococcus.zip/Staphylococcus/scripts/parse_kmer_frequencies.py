import os
import pandas as pd
from skbio import DNA
from collections import Counter

# parameters
k = 7  # change as needed
input_folder = "../data/raw_genomes/"
output_file = f"../results/kmers/k{k}_frequency_matrix.csv"

def get_kmer_counts(seq, k):
    seq = seq.upper()
    valid_kmers = []
    for i in range(len(seq) - k + 1):
        kmer = seq[i:i+k]
        if all(base in "ACGT" for base in kmer):
            valid_kmers.append(kmer)
    return Counter(valid_kmers)

def parse_fna_file(filepath, k):
    with open(filepath) as f:
        lines = [line.strip() for line in f if not line.startswith(">")]
    sequence = "".join(lines)
    return get_kmer_counts(sequence, k)

# loop over .fna files
records = {}
for filename in os.listdir(input_folder):
    if filename.endswith(".fna"):
        genome_id = filename.replace(".fna", "")
        path = os.path.join(input_folder, filename)
        counts = parse_fna_file(path, k)
        records[genome_id] = counts

# build dataframe
df = pd.DataFrame.from_dict(records, orient="index").fillna(0)

# normalize k-mer frequencies (row-wise)
df = df.div(df.sum(axis=1), axis=0)

# save matrix
df.to_csv(output_file)
print(f"k-mer frequency matrix saved to {output_file}")