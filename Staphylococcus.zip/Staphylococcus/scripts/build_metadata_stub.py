import pandas as pd

# accurate metadata for all 25 genomes
metadata = pd.DataFrame([
    {"filename": "1280.35615.fna", "host_species": "Homo sapiens", "country": "Kazakhstan", "isolation_source": "Swab from ear", "collection_date": "2021-06-10"},
    {"filename": "1280.35616.fna", "host_species": "Homo sapiens", "country": "Kazakhstan", "isolation_source": "Swab from Wound", "collection_date": "2021-06-18"},
    {"filename": "1282.4566.fna", "host_species": "Homo sapiens", "country": "Kazakhstan", "isolation_source": "Swab from ear", "collection_date": "2021-06-10"},
    {"filename": "1280.39427.fna", "host_species": "Homo sapiens", "country": "China", "isolation_source": "nasal swab", "collection_date": "2018-12-20"},
    {"filename": "1280.53115.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2021-10-08"},
    {"filename": "1280.53240.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2022-01-05"},
    {"filename": "1280.53241.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2022-01-13"},
    {"filename": "1280.53227.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2018-08-05"},
    {"filename": "1280.53239.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2022-01-10"},
    {"filename": "1280.53145.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2021-09-14"},
    {"filename": "1280.53255.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2018-09-28"},
    {"filename": "1280.53256.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2021-11-09"},
    {"filename": "1280.53254.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2021-11-03"},
    {"filename": "1280.53250.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2021-11-11"},
    {"filename": "1280.53253.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2022-01-14"},
    {"filename": "1280.53257.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2021-11-17"},
    {"filename": "1280.53259.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2021-11-08"},
    {"filename": "1280.53258.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2021-08-01"},
    {"filename": "1280.53252.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2020-10-12"},
    {"filename": "1280.53138.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2021-08-13"},
    {"filename": "1280.53228.fna", "host_species": "Homo sapiens", "country": "USA", "isolation_source": "blood", "collection_date": "2018-11-05"},
    {"filename": "1280.16560.fna", "host_species": "Homo sapiens newborn", "country": "Brazil", "isolation_source": "Antonio Pedro University Hospital", "collection_date": "2009-01-01"},
    {"filename": "1280.49525.fna", "host_species": "Homo sapiens", "country": "Kenya", "isolation_source": "clinical", "collection_date": "2020-01-01"},
    {"filename": "1280.49551.fna", "host_species": "Homo sapiens", "country": "Kenya", "isolation_source": "clinical", "collection_date": "2022-01-01"},
    {"filename": "1280.49572.fna", "host_species": "Homo sapiens", "country": "Kenya", "isolation_source": "clinical", "collection_date": "2016-01-01"}
])

# save the metadata file
metadata.to_csv("../metadata/sample_metadata.csv", index=False)
print("Accurate metadata saved to metadata/sample_metadata.csv")