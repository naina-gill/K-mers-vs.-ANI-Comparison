import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# Toggle this to True if you want to annotate points
SHOW_LABELS = False

# File paths
mash_file = "../results/tables/mash_distances.tsv"
metadata_file = "results/ani/grouped_metadata.csv"
output_plot = "results/figures/mash_pca_cluster_plot.png"

# Load Mash matrix
dist = pd.read_csv(mash_file, sep="\t", index_col=0)
dist.index = dist.index.astype(str).str.strip()
dist.columns = dist.columns.astype(str).str.strip()
print("Mash matrix shape:", dist.shape)

# Load metadata
meta = pd.read_csv(metadata_file)
meta["filename_base"] = (
    meta["filename"]
    .astype(str)
    .str.replace(".fna", "", regex=False)
    .str.strip()
)

# Precision patch for IDs
def correct_id(id_str, valid_ids):
    try:
        float_val = float(id_str)
        padded = f"{float_val:.5f}"
        if padded in valid_ids:
            return padded
        stripped = padded.rstrip("0").rstrip(".")
        if stripped in valid_ids:
            return stripped
    except Exception:
        pass
    return id_str

valid_ids = set(dist.index)
meta["genome_id"] = meta["filename_base"].apply(
    lambda x: correct_id(x, valid_ids)
)

# Strict intersection for valid Mash keys
matched_ids = sorted(
    dist.index.intersection(dist.columns).intersection(meta["genome_id"])
)
print("Confirmed matched genome IDs:", len(matched_ids))

# Subset matrix and metadata
dist = dist.loc[matched_ids, matched_ids]
meta = meta[meta["genome_id"].isin(matched_ids)].reset_index(drop=True)
print("Final Mash matrix shape:", dist.shape)

# PCA
pca = PCA(n_components=2)
coords = pca.fit_transform(dist)
print("PCA coordinates shape:", coords.shape)

# Clustering
best_score = -1
best_k = None
best_labels = None

for k in range(2, min(len(coords), 6)):
    try:
        labels = KMeans(n_clusters=k, random_state=42).fit_predict(coords)
        score = silhouette_score(coords, labels)
        print(f"n_clusters = {k}, silhouette = {score:.3f}")
        if score > best_score:
            best_score = score
            best_k = k
            best_labels = labels
    except Exception as e:
        print(f"Clustering failed for k={k}: {e}")

if best_labels is None:
    raise ValueError("No valid clustering solution found.")

# Color mapping by isolation source
sources = sorted(meta["isolation_source"].dropna().unique())
color_map = {src: plt.cm.Set2(i % 8) for i, src in enumerate(sources)}
colors = [color_map.get(src, "gray") for src in meta["isolation_source"]]

# Plot
plt.figure(figsize=(10, 8))
plt.scatter(coords[:, 0], coords[:, 1], c=colors, s=60)

if SHOW_LABELS:
    for i, label in enumerate(matched_ids):
        plt.text(coords[i, 0], coords[i, 1], label, fontsize=7)

plt.title(f"Mash PCA Clustering (k={best_k}, Silhouette = {best_score:.3f})")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.tight_layout()

# Legend
handles = [
    plt.Line2D(
        [0], [0], marker='o', color='w', label=src,
        markerfacecolor=color_map[src], markersize=8
    )
    for src in sources
]
plt.legend(handles=handles, title="Isolation Source", loc="best")

# Save
os.makedirs(os.path.dirname(output_plot), exist_ok=True)
plt.savefig(output_plot, dpi=300)
plt.close()
print(f"Saved Mash PCA plot to {output_plot}")