import os

# Input genome folder
genome_dir = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/raw_genomes/"

# Output path
manifest_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/genome_paths.txt"

def find_fna_files(directory):
    """Return full paths of all .fna files in the genome directory."""
    fna_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(".fna"):
                full_path = os.path.join(root, file)
                fna_files.append(os.path.abspath(full_path))
    return sorted(fna_files)

def write_manifest(fna_list, out_path):
    """Write each .fna path to the manifest output file."""
    with open(out_path, "w") as out_file:
        for path in fna_list:
            out_file.write(path + "\n")

    print(f"\nManifest created with {len(fna_list)} genomes.")
    print("Output saved to:", out_path)

def main():
    fna_files = find_fna_files(genome_dir)
    if not fna_files:
        print("No .fna files found. Check genome_dir.")
        return
    write_manifest(fna_files, manifest_path)

if __name__ == "__main__":
    main()