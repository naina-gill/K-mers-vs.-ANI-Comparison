import os
import pandas as pd

# === Input/Output paths ===
matrix_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/results/ani_raw.tsv.matrix"
output_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/results/ani_distance_matrix.tsv"

def parse_fastani_matrix(path):
    with open(path, "r") as f:
        lines = [line.strip() for line in f if line.strip()]

    # First line: total genomes
    n = int(lines[0])
    genome_ids = [os.path.basename(lines[i]) for i in range(1, n + 1)]

    # Initialize empty ANI matrix
    ani = pd.DataFrame(100.0, index=genome_ids, columns=genome_ids)

    # Fill lower triangle
    for row_idx, line in enumerate(lines[n + 1:]):
        fields = line.split()
        ani_values = list(map(float, fields[1:]))
        for col_idx, val in enumerate(ani_values):
            # FastANI matrix is lower triangle: row = idx + 1, col = col_idx
            q_id = genome_ids[row_idx + 1]
            r_id = genome_ids[col_idx]
            ani.at[q_id, r_id] = val
            ani.at[r_id, q_id] = val  # symmetry

    # Convert to distance
    dist = 100.0 - ani
    return dist

def main():
    dist_df = parse_fastani_matrix(matrix_path)
    dist_df.to_csv(output_path, sep="\t", index=True, header=True)
    print("✔ Distance matrix written to:", output_path)

if __name__ == "__main__":
    main()