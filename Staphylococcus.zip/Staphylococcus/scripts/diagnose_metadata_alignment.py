import pandas as pd
import os

# Define file paths
metadata_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/metadata/curated_metadata.tsv"
genome_dir = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/raw_genomes"
output_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/metadata/validated_metadata.tsv"

# Load metadata with explicit type for assembly_id
metadata = pd.read_csv(metadata_path, sep="\t", dtype={"assembly_id": str})

# Strip whitespace from all string columns
metadata = metadata.apply(lambda col: col.map(lambda x: x.strip() if isinstance(x, str) else x))

# Ensure assembly_id is a clean string
metadata["assembly_id"] = metadata["assembly_id"].astype(str).str.strip()

# List all genome files and extract genome IDs
fna_files = [f for f in os.listdir(genome_dir) if f.endswith(".fna")]
genome_ids = set(f.replace(".fna", "").strip() for f in fna_files)

# Compare genome IDs to metadata
metadata["has_genome_file"] = metadata["assembly_id"].isin(genome_ids)

# Save matched rows
matched = metadata[metadata["has_genome_file"]].copy()
matched.to_csv(output_path, sep="\t", index=False)

# Report summary
missing_count = (~metadata["has_genome_file"]).sum()
extra_files = genome_ids - set(metadata["assembly_id"])

print(f"Validated metadata saved to: {output_path}")
print(f"{len(matched)} metadata entries matched genome files")

if missing_count > 0:
    print(f"{missing_count} metadata rows have no matching .fna file")

if extra_files:
    print("Unmatched genome files:")
    for genome_id in sorted(extra_files):
        print(f"{genome_id}.fna")