import pandas as pd
import matplotlib.pyplot as plt
from sklearn.manifold import MDS

# load cleaned distance matrix
df = pd.read_csv("../results/ani/ani_distance_matrix_clean.csv", index_col=0)

# simplify genome labels
labels = [name.replace(".fna", "") for name in df.index]

# perform MDS
mds = MDS(n_components=2, dissimilarity="precomputed", random_state=42)
coords = mds.fit_transform(df.values)

# create scatter plot
plt.figure(figsize=(10, 8))
plt.scatter(coords[:, 0], coords[:, 1], s=60)
for i, label in enumerate(labels):
    plt.text(coords[i, 0], coords[i, 1], label, fontsize=8)

plt.title("MDS of ANI-Based Genome Distances")
plt.xlabel("MDS Dimension 1")
plt.ylabel("MDS Dimension 2")
plt.tight_layout()

# save plot
plt.savefig("../results/ani/mds_plot.png", dpi=300)
print("MDS plot saved to results/ani/mds_plot.png")