import pandas as pd
import os

# File paths
metadata_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/metadata/validated_metadata.tsv"
genome_dir = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/raw_genomes"
manifest_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/genome_manifest.tsv"

# Load validated metadata
metadata = pd.read_csv(metadata_path, sep="\t")

# Strip whitespace from all string fields
metadata = metadata.apply(lambda col: col.map(lambda x: x.strip() if isinstance(x, str) else x))

# Construct genome file paths
metadata["genome_path"] = metadata["assembly_id"].apply(
    lambda aid: os.path.join(genome_dir, f"{aid}.fna")
)

# Select relevant columns for the manifest
manifest = metadata[[
    "genome_path",
    "assembly_id",
    "genome_name",
    "isolation_source",
    "collection_date"
]]

# Save manifest as a tab-separated file
manifest.to_csv(manifest_path, sep="\t", index=False)

# Confirmation output
print(f"Manifest file generated: {manifest_path}")
print(f"{len(manifest)} genome entries written.")