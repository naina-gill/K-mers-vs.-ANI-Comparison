import pandas as pd

# Parameters
k = 7
input_file = f"../results/kmers/k{k}_frequency_matrix.csv"
top_n = 10
output_file = f"../results/kmers/top_kmers_k{k}.csv"

# Load matrix and run PCA
df = pd.read_csv(input_file, index_col=0)
from sklearn.decomposition import PCA
pca = PCA(n_components=2)
pca.fit(df)

# Get loadings for PC1
loadings = pd.Series(pca.components_[0], index=df.columns)

# Top motifs
top_kmers = loadings.abs().sort_values(ascending=False).head(top_n)
motifs = pd.DataFrame({
    "kmer": top_kmers.index,
    "PC1_loading": loadings[top_kmers.index],
    "GC_content": [round((kmer.count("G") + kmer.count("C")) / len(kmer), 3) for kmer in top_kmers.index],
    "Palindromic": [kmer == kmer[::-1] for kmer in top_kmers.index]
})

# Save
motifs.to_csv(output_file, index=False)
print(f"Top {top_n} k-mers driving PC1 saved to {output_file}")