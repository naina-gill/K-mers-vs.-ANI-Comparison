import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# File paths
matrix_file = "../results/tables/fastani_output.txt.matrix"
metadata_file = "../results/ani/grouped_metadata.csv"
output_plot = "../results/figures/ani_pca_cluster_plot.png"

# Parse genome paths from FastANI matrix
with open(matrix_file) as f:
    lines = f.readlines()

genome_paths = []
for line in lines[1:]:
    if ".fna" in line:
        genome_paths.append(line.strip().split()[0])

genome_ids = [os.path.basename(p).replace(".fna", "").replace(".fasta", "").strip() for p in genome_paths]
n = len(genome_ids)
matrix = np.zeros((n, n))

# Parse lower triangular values
row = 0
col_offset = 0
for line in lines[len(genome_ids) + 1:]:
    fields = line.strip().split()
    for i, val in enumerate(fields):
        matrix[row, col_offset + i] = float(val)
        matrix[col_offset + i, row] = float(val)
    row += 1
    col_offset += 1

dist = pd.DataFrame(matrix, index=genome_ids, columns=genome_ids)
print("Constructed symmetric ANI matrix:", dist.shape)

# Load metadata
meta = pd.read_csv(metadata_file)
meta["genome_id"] = meta["filename"].str.extract(r"(\d+\.\d+)", expand=False).astype(str).str.strip()

dist.index = dist.index.astype(str).str.strip()
dist.columns = dist.columns.astype(str).str.strip()

common_ids = dist.index.intersection(meta["genome_id"].dropna())
print("Matched genome IDs:", len(common_ids))
if len(common_ids) < 3:
    raise ValueError("Too few genomes matched")

dist = dist.loc[common_ids, common_ids]
meta = meta[meta["genome_id"].isin(common_ids)].reset_index(drop=True)

# PCA
pca = PCA(n_components=2)
coords = pca.fit_transform(dist)
print("PCA coordinates shape:", coords.shape)

# Cluster evaluation loop
unique_coords = np.unique(coords, axis=0)
if len(unique_coords) < 2:
    raise ValueError("Insufficient diversity for clustering")

best_score = -1
best_k = None
best_labels = None

for k in range(2, min(len(coords), 6)):
    labels = KMeans(n_clusters=k, random_state=42).fit_predict(coords)
    try:
        score = silhouette_score(coords, labels)
        print(f"n_clusters = {k}, silhouette = {score:.3f}")
        if score > best_score:
            best_score = score
            best_k = k
            best_labels = labels
    except ValueError:
        continue

if best_labels is None:
    raise ValueError("No valid clustering found")

# Color assignment
sources = sorted(meta["isolation_source"].dropna().unique())
color_map = {s: plt.cm.Set2(i % 8) for i, s in enumerate(sources)}
colors = [color_map.get(src, "gray") for src in meta["isolation_source"]]

# Plot
plt.figure(figsize=(10, 8))
plt.scatter(coords[:, 0], coords[:, 1], c=colors, s=60)

for i, label in enumerate(meta["genome_id"]):
    plt.text(coords[i, 0], coords[i, 1], label, fontsize=7)

plt.title(f"ANI PCA Clustering (k={best_k}, Silhouette = {best_score:.3f})")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.tight_layout()

# Legend
handles = [plt.Line2D([0], [0], marker='o', color='w', label=s,
                      markerfacecolor=color_map[s], markersize=8)
           for s in sources]
plt.legend(handles=handles, title="Isolation Source", loc="best")

# Save figure
os.makedirs(os.path.dirname(output_plot), exist_ok=True)
plt.savefig(output_plot, dpi=300)
plt.close()
print(f"Saved ANI PCA plot to {output_plot}")