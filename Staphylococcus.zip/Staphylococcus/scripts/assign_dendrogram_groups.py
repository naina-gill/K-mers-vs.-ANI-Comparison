import pandas as pd
from scipy.cluster.hierarchy import linkage, fcluster

# load cleaned distance matrix
df = pd.read_csv("../results/ani/ani_distance_matrix_clean.csv", index_col=0)

# simplify labels
labels = [name.replace(".fna", "") for name in df.index]

# compute linkage
linked = linkage(df.values, method="average")

# assign groups based on cut threshold
# you can adjust 't' for finer or broader groups
t = 5.0  # cut height
groups = fcluster(linked, t=t, criterion="distance")

# save to TSV
output = pd.DataFrame({"genome": labels, "group": groups})
output.to_csv("../results/ani/genome_groups.tsv", sep="\t", index=False)
print("Group assignments saved to results/ani/genome_groups.tsv")