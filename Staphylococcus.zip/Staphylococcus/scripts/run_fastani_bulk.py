import os
import subprocess

# Directory containing raw genome files
genome_dir = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/raw_genomes"

# Path to FastANI binary
fastani_bin = "/home/anyag/FastANI/build/fastANI"

# Output file for pairwise ANI comparisons
output_tsv = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/results/ani_raw.tsv"

# Optional lower triangle matrix for PCA or clustering
output_matrix = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/results/ani_raw.tsv.matrix"

# Text files listing query and reference genomes (one path per line)
query_list = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/query_list.txt"
reference_list = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/reference_list.txt"

def list_genomes(genome_dir, output_file):
    # Write full paths of all .fna files to a list file
    with open(output_file, "w") as f:
        for fname in sorted(os.listdir(genome_dir)):
            if fname.endswith(".fna"):
                full_path = os.path.join(genome_dir, fname)
                f.write(full_path + "\n")

def run_bulk_fastani(query_list, reference_list, output_file):
    # Run FastANI using query and reference genome lists
    subprocess.run([
        fastani_bin,
        "--ql", query_list,
        "--rl", reference_list,
        "--fragLen", "1000",
        "--minFraction", "0.5",
        "--threads", "4",
        "--matrix",
        "-o", output_file
    ], check=True)

def main():
    # Generate input lists
    list_genomes(genome_dir, query_list)
    list_genomes(genome_dir, reference_list)

    # Run one bulk FastANI comparison job
    run_bulk_fastani(query_list, reference_list, output_tsv)

    print("FastANI bulk comparisons complete.")
    print("Results saved to:", output_tsv)
    print("Matrix saved to:", output_matrix)

if __name__ == "__main__":
    main()