import os
import subprocess
import pandas as pd

# updated path to genome directory
genome_dir = "../data/raw_genomes/"
sketch_file = "../results/kmers/mash_sketch"
dist_output = "../results/kmers/mash_distances.tab"
dist_matrix = "../results/kmers/mash_distance_matrix.csv"

# ensure output folder exists
os.makedirs("../results/kmers/", exist_ok=True)

# list genome files
genomes = sorted([f for f in os.listdir(genome_dir) if f.endswith(".fna")])
genome_paths = [os.path.join(genome_dir, g) for g in genomes]

# sketch genomes
subprocess.run(["mash", "sketch", "-o", sketch_file] + genome_paths)

# compute pairwise distances
with open(dist_output, "w") as f:
    subprocess.run(["mash", "dist", sketch_file + ".msh", sketch_file + ".msh"], stdout=f)

# load Mash tab output and reshape
df = pd.read_csv(dist_output, sep="\t", header=None)
df.columns = ["genome1", "genome2", "distance", "pvalue", "shared"]

# simplify filenames
df["genome1"] = df["genome1"].apply(lambda x: os.path.basename(x).replace(".fna", ""))
df["genome2"] = df["genome2"].apply(lambda x: os.path.basename(x).replace(".fna", ""))

# pivot to distance matrix
pivot = df.pivot(index="genome1", columns="genome2", values="distance")
pivot.to_csv(dist_matrix)
print("Mash distance matrix saved to:", dist_matrix)