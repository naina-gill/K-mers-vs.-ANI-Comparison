import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# Set parameters
k = 7
input_file = f"../results/kmers/k{k}_frequency_matrix.csv"
metadata_file = "../results/ani/grouped_metadata.csv"
output_plot = f"../results/kmers/k{k}_pca_cluster_plot.png"

# Load k-mer frequency matrix
df = pd.read_csv(input_file, index_col=0)
print("Loaded k-mer matrix:", df.shape)

# Load metadata and strip '.fna' from filename to get genome IDs
meta = pd.read_csv(metadata_file)
meta["genome_id"] = meta["filename"].str.replace(".fna", "", regex=False)

# Normalize types and whitespace to ensure alignment
df.index = df.index.astype(str).str.strip()
meta["genome_id"] = meta["genome_id"].astype(str).str.strip()

# Identify shared genome IDs
common_ids = df.index.intersection(meta["genome_id"].dropna())
print("Matched genome IDs:", len(common_ids))
if len(common_ids) < 3:
    raise ValueError("Too few matched genomes between matrix and metadata")

# Filter and align data
df = df.loc[common_ids]
meta = meta[meta["genome_id"].isin(common_ids)].reset_index(drop=True)

# Perform PCA
pca = PCA(n_components=2)
coords = pca.fit_transform(df)
print("PCA coordinates shape:", coords.shape)

# Cluster with KMeans and calculate silhouette score
n_clusters = 3
labels = KMeans(n_clusters=n_clusters, random_state=42).fit_predict(coords)
score = silhouette_score(coords, labels)
print(f"Silhouette score: {score:.3f}")

# Define colors based on ecological niche
sources = sorted(meta["isolation_source"].dropna().unique())
color_map = {s: plt.cm.Set2(i % 8) for i, s in enumerate(sources)}
colors = [color_map.get(src, "gray") for src in meta["isolation_source"]]

# Create PCA scatter plot
plt.figure(figsize=(10, 8))
plt.scatter(coords[:, 0], coords[:, 1], c=colors, s=60)

# Add genome ID labels to each point
for i, label in enumerate(meta["genome_id"]):
    plt.text(coords[i, 0], coords[i, 1], label, fontsize=7)

plt.title(f"k={k} PCA Clustering (Silhouette = {score:.3f})")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.tight_layout()

# Add legend by isolation source
handles = [plt.Line2D([0], [0], marker='o', color='w', label=s,
                      markerfacecolor=color_map[s], markersize=8)
           for s in sources]
plt.legend(handles=handles, title="Isolation Source", loc="best")

# Save plot
os.makedirs(os.path.dirname(output_plot), exist_ok=True)
plt.savefig(output_plot, dpi=300)
plt.close()
print(f"Saved PCA plot to {output_plot}")