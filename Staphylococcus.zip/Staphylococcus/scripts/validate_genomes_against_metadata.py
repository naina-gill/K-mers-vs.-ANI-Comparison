import pandas as pd
import os

# Paths
metadata_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/metadata/curated_metadata.tsv"
genome_dir = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/raw_genomes"
output_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/metadata/validated_metadata.tsv"

# Load and sanitize metadata
metadata = pd.read_csv(metadata_path, sep="\t")

# Strip whitespace from all string values
metadata = metadata.apply(lambda col: col.map(lambda x: x.strip() if isinstance(x, str) else x))

# Make sure assembly_id is a clean string
metadata["assembly_id"] = metadata["assembly_id"].astype(str).str.strip()

# Get cleaned .fna filenames as IDs
fna_files = [f for f in os.listdir(genome_dir) if f.endswith(".fna")]
genome_ids = set(f.replace(".fna", "").strip() for f in fna_files)

# Compare genome IDs to metadata
metadata["has_genome_file"] = metadata["assembly_id"].isin(genome_ids)

# Filter and save matched entries
matched = metadata[metadata["has_genome_file"]].copy()
matched.to_csv(output_path, sep="\t", index=False)

# Summary
missing_count = (~metadata["has_genome_file"]).sum()
extra_files = genome_ids - set(metadata["assembly_id"])

print(f"Validated metadata saved as validated_metadata.tsv")
print(f"{len(matched)} metadata entries matched genome files")

if missing_count > 0:
    print(f"{missing_count} metadata rows have no matching .fna file")

if extra_files:
    print("Unmatched genome files:")
    for genome_id in sorted(extra_files):
        print(f"{genome_id}.fna")