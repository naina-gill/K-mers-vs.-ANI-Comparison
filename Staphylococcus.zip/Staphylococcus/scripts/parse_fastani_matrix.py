import pandas as pd
import numpy as np

def parse_sparse_fastani(file_path, output_path="ani_distance_matrix.csv"):
    pairwise = []
    samples = set()

    # Read and parse FastANI lines
    with open(file_path, "r") as f:
        for line in f:
            parts = line.strip().split("\t")
            if len(parts) < 3:
                continue  # skip malformed lines
            query, ref, ani = parts[0], parts[1], float(parts[2])
            samples.update([query, ref])
            pairwise.append((query, ref, ani))

    samples = sorted(samples)
    index_map = {name: i for i, name in enumerate(samples)}
    n = len(samples)
    matrix = np.zeros((n, n))

    # Fill matrix with ANI values
    for q, r, ani in pairwise:
        i, j = index_map[q], index_map[r]
        matrix[i, j] = ani
        matrix[j, i] = ani  # enforce symmetry

    # Convert ANI to distance
    distance_matrix = 100.0 - matrix

    # Build DataFrame
    df = pd.DataFrame(distance_matrix, index=samples, columns=samples)
    df.to_csv(output_path, float_format="%.6f")

    print(f"✅ Saved symmetric distance matrix to {output_path}")
    print(df.head())

# Example usage
if __name__ == "__main__":
    parse_sparse_fastani("../analysis/ani/fastani_output.txt")