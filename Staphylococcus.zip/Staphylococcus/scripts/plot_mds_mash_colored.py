import pandas as pd
import matplotlib.pyplot as plt
from sklearn.manifold import MDS

# Load Mash matrix
dist_matrix = pd.read_csv("../results/kmers/mash_distance_matrix.csv", index_col=0)
dist_matrix.index = dist_matrix.index.astype(float).astype(str)
dist_matrix.columns = dist_matrix.columns.astype(float).astype(str)

# Load metadata
meta = pd.read_csv("../results/ani/grouped_metadata.csv")
meta["filename"] = meta["filename"].astype(str).str.strip()
meta["mash_label"] = meta["filename"].str.replace(".fna", "", regex=False)
meta["isolation_source"] = meta["isolation_source"].astype(str)

# Filter metadata to match Mash matrix
available = [label for label in meta["mash_label"] if label in dist_matrix.index]
meta = meta[meta["mash_label"].isin(available)].reset_index(drop=True)
dist_matrix = dist_matrix.loc[available, available]

# Run MDS
mds = MDS(n_components=2, dissimilarity="precomputed", random_state=42)
coords = mds.fit_transform(dist_matrix.values)

# Assign colors
sources = sorted(meta["isolation_source"].dropna().unique())
color_map = {s: plt.cm.Set2(i % 8) for i, s in enumerate(sources)}
colors = [color_map[s] for s in meta["isolation_source"]]

# Plot
plt.figure(figsize=(10, 8))
plt.scatter(coords[:, 0], coords[:, 1], c=colors, s=60)

for i, label in enumerate(meta["mash_label"]):
    plt.text(coords[i, 0], coords[i, 1], label, fontsize=7)

plt.title("Mash MDS Colored by Isolation Source")
plt.xlabel("MDS Dimension 1")
plt.ylabel("MDS Dimension 2")
plt.tight_layout()

# Legend
handles = [plt.Line2D([0], [0], marker='o', color='w', label=s,
                      markerfacecolor=color_map[s], markersize=8)
           for s in sources]
plt.legend(handles=handles, title="Isolation Source", loc="best")

# Save
plt.savefig("../results/kmers/mash_mds_plot_colored.png", dpi=300)
print("Mash-based MDS plot saved to results/kmers/mash_mds_plot_colored.png")