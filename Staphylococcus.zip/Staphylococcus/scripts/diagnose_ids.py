import os
import pandas as pd

# Load FastANI genome paths
with open("../results/tables/fastani_output.txt.matrix") as f:
    lines = f.readlines()[1:26]  # First 25 genome file paths
ani_ids = [os.path.basename(p).replace(".fna", "").replace(".fasta", "").strip() for p in lines]

# Load metadata
meta = pd.read_csv("../results/ani/grouped_metadata.csv")
meta_ids = meta["filename"].str.extract(r"(\d+\.\d+)")[0].dropna().unique().tolist()

# Print outputs
print("ANI genome IDs:\n", ani_ids)
print("\nMetadata genome IDs:\n", meta_ids)

# Show exact overlaps
print("\nMatched IDs:\n", set(ani_ids).intersection(meta_ids))