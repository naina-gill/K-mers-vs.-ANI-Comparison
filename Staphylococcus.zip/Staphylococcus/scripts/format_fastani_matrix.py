import pandas as pd
import os
from collections import defaultdict

# Paths
input_tsv = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/results/ani_raw.tsv"
output_matrix = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/results/ani_distance_matrix.tsv"

def build_distance_matrix(tsv_path):
    """
    Builds a symmetric distance matrix from standard FastANI output.
    Each pairwise ANI value is used to compute distance = 100 - ANI.
    """
    df = pd.read_csv(tsv_path, sep="\t", header=None)
    df.columns = ["query", "ref", "ani", "fragments", "total_fragments"]

    # Extract clean genome IDs from paths
    df["query_id"] = df["query"].apply(os.path.basename)
    df["ref_id"] = df["ref"].apply(os.path.basename)

    # Collect all genome IDs
    genome_ids = sorted(set(df["query_id"]).union(set(df["ref_id"])))
    matrix = pd.DataFrame(100.0, index=genome_ids, columns=genome_ids)

    # Fill in distance values
    for _, row in df.iterrows():
        qid = row["query_id"]
        rid = row["ref_id"]
        distance = 100.0 - row["ani"]
        matrix.at[qid, rid] = distance
        matrix.at[rid, qid] = distance  # enforce symmetry

    # Diagonal values = 0 (self-comparison)
    for gid in genome_ids:
        matrix.at[gid, gid] = 0.0

    return matrix

def main():
    dist = build_distance_matrix(input_tsv)
    dist.to_csv(output_matrix, sep="\t", index=True, header=True)
    print("Distance matrix saved to:", output_matrix)

if __name__ == "__main__":
    main()