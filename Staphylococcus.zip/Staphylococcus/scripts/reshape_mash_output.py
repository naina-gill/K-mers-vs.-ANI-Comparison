import os
import pandas as pd

# Input and output paths
input_file = "mash_output.txt"
output_file = "../results/tables/mash_distances.tsv"

# Parse raw Mash output
pairs = []
with open(input_file) as f:
    for line in f:
        fields = line.strip().split()
        if len(fields) >= 3:
            g1 = os.path.basename(fields[0]).replace(".fna", "").strip()
            g2 = os.path.basename(fields[1]).replace(".fna", "").strip()
            dist = float(fields[2])
            pairs.append((g1, g2, dist))

# Build symmetric matrix
ids = sorted(set([p[0] for p in pairs] + [p[1] for p in pairs]))
matrix = pd.DataFrame(1.0, index=ids, columns=ids)
for g1, g2, dist in pairs:
    matrix.at[g1, g2] = dist
    matrix.at[g2, g1] = dist

print(f"Parsed Mash pairs: {len(pairs)}")
print(f"Matrix shape: {matrix.shape}")

# Save output
os.makedirs(os.path.dirname(output_file), exist_ok=True)
matrix.to_csv(output_file, sep="\t")
print(f"Saved symmetric Mash matrix to {output_file}")