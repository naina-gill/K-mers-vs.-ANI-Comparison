#!/usr/bin/env python3
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.manifold import MDS
from pathlib import Path

# Resolve project root (two levels up from this script)
script_path = Path(__file__).resolve()
project_root = script_path.parent.parent

# File paths
meta_fp = project_root / "results" / "ani" / "grouped_metadata.csv"
dist_fp = project_root / "results" / "ani" / "ani_distance_matrix_clean.csv"
output_fp = project_root / "results" / "ani" / "mds_plot_colored.png"

# Load metadata
meta = pd.read_csv(meta_fp)
meta["filename"] = meta["filename"].astype(str)
labels = [f.replace(".fna", "") for f in meta["filename"]]

# Load ANI distance matrix
dist_matrix = pd.read_csv(dist_fp, index_col=0)

# Run MDS
mds = MDS(
    n_components=2,
    dissimilarity="precomputed",
    random_state=42
)
coords = mds.fit_transform(dist_matrix.values)

# Prepare colors
meta["isolation_source"] = meta["isolation_source"].astype(str)
unique_sources = sorted(meta["isolation_source"].dropna().unique())
color_map = {src: plt.cm.Set2(i % 8) for i, src in enumerate(unique_sources)}
colors = [color_map[src] for src in meta["isolation_source"]]

# Plot (no labels)
plt.figure(figsize=(10, 8))
plt.scatter(coords[:, 0], coords[:, 1], c=colors, s=60)

plt.title("MDS Colored by Isolation Source")
plt.xlabel("MDS Dimension 1")
plt.ylabel("MDS Dimension 2")
plt.tight_layout()

# Legend
handles = [
    plt.Line2D(
        [0], [0],
        marker='o', color='w',
        label=src,
        markerfacecolor=color_map[src],
        markersize=8
    )
    for src in unique_sources
]
plt.legend(handles=handles, title="Isolation Source", loc="best")

# Save
output_fp.parent.mkdir(parents=True, exist_ok=True)
plt.savefig(output_fp, dpi=300)
plt.close()
print(f"MDS plot saved to {output_fp}")