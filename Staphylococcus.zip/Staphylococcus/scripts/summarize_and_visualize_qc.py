import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Input
qc_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/genome_qc_summary.tsv"

# Output directory for plots
plot_dir = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/plots/"

# Ensure plot style
sns.set(style="whitegrid")

def load_qc_data(path):
    df = pd.read_csv(path, sep="\t")
    df = df.dropna(subset=["gc_content", "total_length"])
    return df

def summarize_statistics(df):
    summary = {
        "Genome count": len(df),
        "Mean total length (bp)": round(df["total_length"].mean(), 2),
        "Median total length (bp)": round(df["total_length"].median(), 2),
        "Min/Max length": (df["total_length"].min(), df["total_length"].max()),
        "Mean GC content (%)": round(df["gc_content"].mean(), 2),
        "Median GC content (%)": round(df["gc_content"].median(), 2),
        "GC range (%)": (df["gc_content"].min(), df["gc_content"].max())
    }
    print("\n📊 Genome QC Summary:")
    for k, v in summary.items():
        print(f"{k}: {v}")

def plot_gc_vs_length(df):
    plt.figure(figsize=(8, 6))
    sns.scatterplot(x="gc_content", y="total_length", data=df, s=80, edgecolor="black")
    plt.title("GC Content vs Genome Length", fontsize=14)
    plt.xlabel("GC Content (%)")
    plt.ylabel("Total Length (bp)")
    plt.tight_layout()
    plt.savefig(plot_dir + "gc_vs_length.png")
    plt.close()

def plot_histogram(df, column, xlabel, title, filename):
    plt.figure(figsize=(8, 6))
    sns.histplot(df[column], bins=15, kde=True)
    plt.title(title, fontsize=14)
    plt.xlabel(xlabel)
    plt.ylabel("Genome Count")
    plt.tight_layout()
    plt.savefig(plot_dir + filename)
    plt.close()

def run_phase3():
    df = load_qc_data(qc_path)
    summarize_statistics(df)

    plot_gc_vs_length(df)
    plot_histogram(df, "gc_content", "GC Content (%)", "Distribution of GC Content", "gc_content_histogram.png")
    plot_histogram(df, "total_length", "Total Length (bp)", "Distribution of Genome Lengths", "genome_length_histogram.png")
    plot_histogram(df, "sequence_count", "Number of Sequences", "Distribution of Sequence Counts", "sequence_count_histogram.png")

    print("\n All visualizations saved to:", plot_dir)

if __name__ == "__main__":
    run_phase3()