import pandas as pd

# Load validated metadata
meta = pd.read_csv("../data/metadata/validated_metadata.tsv", sep="\t")

# Build filename to match .fna files
meta["filename"] = meta["assembly_id"].astype(str) + ".fna"

# Save curated metadata
selected = meta[["filename", "isolation_source", "host_species", "country", "collection_date"]]
selected.to_csv("../results/ani/grouped_metadata.csv", index=False)
print("Metadata merged and saved to results/ani/grouped_metadata.csv")