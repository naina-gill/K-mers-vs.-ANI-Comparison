import pandas as pd
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram
from collections import Counter
from matplotlib import colors


# Load distance matrix
df = pd.read_csv("../results/ani/ani_distance_matrix_clean.csv", index_col=0)
df.index = df.index.astype(str).str.replace(".fna", "", regex=False).str.strip()
df.columns = df.columns.astype(str).str.replace(".fna", "", regex=False).str.strip()

# Load metadata
meta = pd.read_csv("../data/metadata/curated_metadata.tsv", sep="\t")
meta.columns = meta.columns.str.strip()
meta["assembly_id"] = meta["assembly_id"].astype(str).str.strip()

# Build label + color source map
meta = meta.set_index("assembly_id")
meta = meta.reindex(df.index)

labels = meta["genome_name"].combine_first(pd.Series(meta.index, index=meta.index)).astype(str).tolist()
sources = meta["isolation_source"].fillna("Unknown")
src_set = sorted(sources.dropna().unique())
color_map = {src: plt.cm.Set2(i % 8) for i, src in enumerate(src_set)}

# Compute clustering
linked = linkage(df.values, method="average")
n = df.shape[0]
cluster_members = {}
for i, (l, r, *_rest) in enumerate(linked):
    cid = n + i
    members = set()
    for child in (int(l), int(r)):
        members |= {child} if child < n else cluster_members[child]
    cluster_members[cid] = members

def branch_color(cid):
    """Always return a valid matplotlib color — fallback to 'gray'."""
    try:
        if cid < n:
            src = sources.iloc[cid]
        else:
            srcs = [sources.iloc[i] for i in cluster_members[cid] if pd.notna(sources.iloc[i])]
            src  = Counter(srcs).most_common(1)[0][0] if srcs else "Unknown"
        color = color_map.get(src, "gray")
        # Convert RGBA/RGB tuple to a valid matplotlib hex string
        if isinstance(color, tuple):
            return plt.colors.to_hex(color)
        if isinstance(color, str):
            return color
        return "gray"
    except Exception:
        return "gray"


# Plot dendrogram
plt.figure(figsize=(20, 10))
dendrogram(
    linked,
    labels=labels,
    leaf_rotation=90,
    leaf_font_size=8,
    link_color_func=branch_color,
    color_threshold=0,
)

plt.title("ANI-Based Hierarchical Clustering\nBranches Colored by Isolation Source")
plt.ylabel("ANI Distance")
plt.tight_layout()
plt.savefig("../results/ani/dendrogram_strain_colored.png", dpi=300)
plt.close()
print("✅ Dendrogram saved.")