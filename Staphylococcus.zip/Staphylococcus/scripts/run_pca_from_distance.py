import pandas as pd
from sklearn.decomposition import PCA

# File paths
matrix_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/results/ani_distance_matrix.tsv"
output_path = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/results/pca_coordinates.tsv"

def run_pca(matrix_path, output_path, n_components=3):
    """
    Load a validated distance matrix and compute top n PCA coordinates.
    Expects a square numeric matrix with genome IDs as both row and column headers.
    """
    # Load distance matrix with index
    dist_df = pd.read_csv(matrix_path, sep="\t", index_col=0)

    # Enforce numeric columns and matching index
    dist_df = dist_df.loc[dist_df.index.intersection(dist_df.columns)]
    dist_df = dist_df[dist_df.index]  # re-order columns to match rows

    # Validate shape
    if dist_df.shape[0] != dist_df.shape[1]:
        raise ValueError("Matrix is not square")
    if not (dist_df.dtypes == float).all():
        raise ValueError("Matrix contains non-numeric values")

    # Perform PCA
    pca = PCA(n_components=n_components)
    coords = pca.fit_transform(dist_df.to_numpy())

    # Save PCA coordinates
    coord_df = pd.DataFrame(coords, index=dist_df.index,
                            columns=[f"PC{i+1}" for i in range(n_components)])
    coord_df.to_csv(output_path, sep="\t", index=True)
    print("PCA coordinates written to:", output_path)

if __name__ == "__main__":
    run_pca(matrix_path, output_path)