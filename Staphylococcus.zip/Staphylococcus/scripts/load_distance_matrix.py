import pandas as pd

# Load the original distance matrix
df = pd.read_csv("../results/ani/ani_distance_matrix.csv", index_col=0)

# Simplify labels by stripping file paths
df.index = df.index.map(lambda x: x.split("/")[-1])
df.columns = df.columns.map(lambda x: x.split("/")[-1])

# Validate symmetry
if not df.equals(df.T):
    print("Warning: Matrix is not symmetric")

# Preview matrix and save cleaned version
print("Matrix shape:", df.shape)
print(df.head())

# Save cleaned matrix
df.to_csv("../results/ani/ani_distance_matrix_clean.csv", float_format="%.6f")
print("Cleaned matrix saved to results/ani/ani_distance_matrix_clean.csv")