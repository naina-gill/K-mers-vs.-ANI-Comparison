import requests
import csv

# BV-BRC query to fetch metadata and genome ID for downloading later
query_url = (
    "https://www.bv-brc.org/api/genome/?http_accept=application/json"
    "&eq(genus,Staphylococcus)"
    "&ne(isolation_source,unknown)"
    "&ne(host_name,unknown)"
    "&ne(isolation_country,unknown)"
    "&ne(collection_date,unknown)"
    "&eq(public,1)"
    "&eq(genome_status,Complete)"
)

response = requests.get(query_url)

if response.status_code == 200:
    data = response.json()
    genomes = data if isinstance(data, list) else data.get("response", {}).get("docs", [])

    if genomes:
        with open("staph_metadata.tsv", "w", newline='', encoding='utf-8') as f:
            writer = csv.writer(f, delimiter='\t')
            writer.writerow([
                "Genome Name",
                "Genome ID",
                "Host Name",
                "Isolation Country",
                "Isolation Source",
                "Collection Date"
            ])
            for genome in genomes:
                writer.writerow([
                    genome.get("genome_name", "N/A"),
                    genome.get("genome_id", "N/A"),
                    genome.get("host_name", "N/A"),
                    genome.get("isolation_country", "N/A"),
                    genome.get("isolation_source", "N/A"),
                    genome.get("collection_date", "N/A")
                ])
        print("Metadata with genome IDs saved to staph_metadata.tsv.")
    else:
        print("No genomes matched the query conditions.")
else:
    print("Request failed. Status code:", response.status_code)