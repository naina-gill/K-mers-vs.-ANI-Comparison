import pandas as pd
import os

# Define input/output paths using WSL-compatible format
base_dir = "/mnt/c/Users/anyag/bioinfo_project_folder/Staphylococcus/data/metadata"
input_file = os.path.join(base_dir, "staph_metadata.tsv")
output_file = os.path.join(base_dir, "curated_metadata.tsv")

# Map original column names to standardized names
column_map = {
    "Genome Name": "genome_name",
    "Genome ID": "assembly_id",
    "Host Name": "host_species",
    "Isolation Country": "country",
    "Isolation Source": "isolation_source",
    "Collection Date": "collection_date"
}

# Read metadata and rename columns
df = pd.read_csv(input_file, sep="\t")
df = df.rename(columns=column_map)

# Remove extra spaces from string values
df = df.apply(lambda col: col.map(lambda x: x.strip() if isinstance(x, str) else x))

# Convert collection_date to YYYY-MM-DD format
def normalize_date(date):
    try:
        return pd.to_datetime(date).strftime("%Y-%m-%d")
    except:
        return date

df["collection_date"] = df["collection_date"].apply(normalize_date)

# Check for missing values
missing = df.isna().sum()
missing = missing[missing > 0]

# Write cleaned metadata file
df.to_csv(output_file, sep="\t", index=False)
print("Cleaned metadata saved as curated_metadata.tsv")

# Print summary of missing fields
if not missing.empty:
    print("Missing values:")
    for col, count in missing.items():
        print(f"{col}: {count}")