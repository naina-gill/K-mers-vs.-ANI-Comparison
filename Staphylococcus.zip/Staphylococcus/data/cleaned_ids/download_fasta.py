import csv
import requests
import os
import re

# Create a directory to store downloaded FASTA files
os.makedirs("genomes_fasta", exist_ok=True)

# Open the metadata file and iterate through genome entries
with open("staph_metadata.tsv", "r", encoding="utf-8") as metadata_file:
    reader = csv.DictReader(metadata_file, delimiter="\t")
    for row in reader:
        genome_id = row["Genome ID"]
        genome_name_raw = row["Genome Name"]

        # Clean the genome name to make it safe for filenames
        genome_name = re.sub(r"[^\w\-]", "_", genome_name_raw).strip("_")[:50]

        # Construct the BV-BRC URL for full genome FASTA download
        fasta_url = f"https://www.bv-brc.org/api/genome/{genome_id}?http_accept=application/dna+fasta"

        try:
            response = requests.get(fasta_url)
            if response.status_code == 200:
                # Save the FASTA content to a file
                filename = f"genomes_fasta/{genome_name}_{genome_id}.fna"
                with open(filename, "w", encoding="utf-8") as fasta_file:
                    fasta_file.write(response.text)
                print(f"Saved: {filename}")
            else:
                # Handle unsuccessful HTTP response
                print(f"Failed to download genome {genome_id} (HTTP {response.status_code})")
        except Exception as error:
            # Handle network or file system errors
            print(f"Error retrieving genome {genome_id}: {error}")