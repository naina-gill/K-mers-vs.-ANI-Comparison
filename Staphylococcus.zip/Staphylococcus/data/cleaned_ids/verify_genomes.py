import csv
import os

# Define paths
metadata_file = "staph_metadata.tsv"
fasta_folder = "."
expected_suffix = ".fna"

# Track genome IDs from metadata
expected_ids = set()
with open(metadata_file, "r", encoding="utf-8") as f:
    reader = csv.DictReader(f, delimiter="\t")
    for row in reader:
        genome_id = row["Genome ID"]
        expected_ids.add(genome_id)

# Find all .fna files in the folder
actual_files = [f for f in os.listdir(fasta_folder) if f.endswith(expected_suffix)]

# Match genome IDs from file names
matched_ids = set()
for filename in actual_files:
    for genome_id in expected_ids:
        if genome_id in filename:
            matched_ids.add(genome_id)
            break

# Report results
missing_ids = expected_ids - matched_ids
unexpected_files = [f for f in actual_files if not any(gid in f for gid in expected_ids)]

print(f"Total metadata entries: {len(expected_ids)}")
print(f"Total .fna files found: {len(actual_files)}")
print(f"Matched genome files:   {len(matched_ids)}\n")

if missing_ids:
    print("Missing genome files for:")
    for gid in sorted(missing_ids):
        print(f"  - {gid}")
else:
    print("All metadata entries have matching genome files.")

if unexpected_files:
    print("\nUnmatched files in folder:")
    for fname in unexpected_files:
        print(f"  - {fname}")